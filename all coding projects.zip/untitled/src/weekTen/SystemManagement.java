package weekTen;

import java.util.ArrayList;
import java.util.Scanner;

public class SystemManagement {
    static Scanner scanner = new Scanner(System.in);
    public static void main(String args[]){
        ArrayList<String> names = new ArrayList<>();
        ArrayList<Integer> numbers = new ArrayList<>();
        ArrayList<String> doubles = new ArrayList<>();


        while(true){
            String entry = scanner.nextLine();
            if(entry.equals('q')){
                break;
            }else {
                names.add(entry);


            }
            int entry_2 = scanner.nextInt();
            if(entry.equals('q')){
                break;
            }else {
                numbers.add(entry_2);


            }

            scanner.close();
        }






    }


}
