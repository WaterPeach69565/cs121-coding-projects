package weekTen;

public class test {
    public static void main(String args[]){

    hasmapdata resveratio1 = new hasmapdata("Drew","7:30 PM","No Shrimp");

        hasmapdata resveratio2 = new hasmapdata("Nate","7:30 PM","No Shrimp");

        hasmapdata resveratio3 = new hasmapdata("Erik","8:30 PM","No request");
        resturanthasmap resturantreservation = new resturanthasmap();
        resturantreservation.addspecial("R82",resveratio1);
        resturantreservation.addspecial("R83",resveratio2);
        resturantreservation.addspecial("R84",resveratio3);
        System.out.println(resturantreservation.getInfo("R82"));
        resturantreservation.getallspecial();
        resturantreservation.removespecial("R84");

    }
}
