package weekTen;

import java.util.LinkedList;

public class linkedlist {
    public static void main(String args[]){
        String name = "Drew";
        String email = "d_meyers42@yahoo.com";
        String phone_number = "(317)914-9240";
        int late_few = 4;
        String [] BorrowedBook = {"F451","Glass Castle","To Kill a Mocking Bird","Of Mice and Men"};
        double newfee = 0.0;


        LinkedList<String> information = new LinkedList<String>();
        information.add("information:");
            information.add(name);
            information.add(email);
            information.add(phone_number);
        information.add(" Borrowed Books:");



        for(int i = 0; i<BorrowedBook.length;i++){
            information.add(BorrowedBook[i]);


        }



        for(int i = 0; i <BorrowedBook.length;i++)
        {
             newfee = late_few + 1.50;

        }
        String final_string = Double.toString(newfee);
        information.add(" late fee:");

        information.add(final_string);

        System.out.println(information);
    }
}
