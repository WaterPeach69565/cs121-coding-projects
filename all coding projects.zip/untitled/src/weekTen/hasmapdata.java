package weekTen;

public class hasmapdata {
    private  String name;
    private  String reservation_time;
    private  int Table_number;
    private  String ID;
    private  String requstdetails;

    public hasmapdata(String name, String reservation_time,String requstdetails){
        this.name = name;
        this.requstdetails= requstdetails;
        this.reservation_time = reservation_time;



    }
    @Override
    public String toString(){
        return String.format(name,requstdetails,reservation_time);

    }
}
