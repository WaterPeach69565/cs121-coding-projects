package weekTen;

import java.util.HashMap;
import java.util.Scanner;

public class resturanthasmap {
public static void main(String args[]){



}
    static Scanner scanner = new Scanner(System.in);

         HashMap<String,hasmapdata> specialrequsts = new HashMap<>();


     public void addspecial(String ID,hasmapdata hasmapdata){
        specialrequsts.putIfAbsent(ID,hasmapdata);

     }
     public String getInfo(String ID){
         return (specialrequsts.get(ID)).toString();
     }
     public void removespecial(String ID){
         specialrequsts.remove(ID);

     }

     public void getallspecial(){
         for (hasmapdata hasmapdata : specialrequsts.values()){
             System.out.println(specialrequsts.toString());

         }

     }
}
