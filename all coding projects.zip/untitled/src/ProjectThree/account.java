package ProjectThree;

import java.util.ArrayList;

public class account {


    public ArrayList<customer> account = new ArrayList<>();
    public ArrayList<Integer> pins = new ArrayList<>();
    private int numberofaccount;
    public void getnum(){
        System.out.println(numberofaccount);
    }





    public void  addaccount(customer Customer){
        account.add(Customer);
        numberofaccount = numberofaccount +1;
        pins.add(Customer.getPin());



    }
    public void  removeaccount(customer Customer){


            account.remove(Customer);
            numberofaccount = numberofaccount -1;
            System.out.println("account closed");






    }
    public void getaccount(customer Customer){
        System.out.println(Customer.getName()+" "+Customer.getPin()+" "+Customer.getbalance());
    }
    public customer verify(int pin,String name,int balance){
        customer Customer = null;
         int fallback = 0;
        for(int i = 0; i<account.toArray().length;i++){
            Customer = account.get(i);
            if(pin == Customer.getPin()&&name.equals(Customer.getName())&&balance == Customer.getbalance()){

                System.out.println(Customer.getName()+" "+Customer.getPin()+" "+Customer.getbalance());

            } else if (pin != Customer.getPin()) {
                Customer = account.get(i);

            }

        }

        return Customer;
    }











}
