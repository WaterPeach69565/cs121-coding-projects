package ProjectThree;





import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class menu {
    static Scanner scanner = new Scanner(System.in);



    public static void main(String args[]) throws IOException {

        int choice = 0;
        int pin = 0;
        int entry = 0;
        int balance = 0;
        String name = "null";
        customer newcustomer = new customer("test1",3558,10000);
        customer newcustomer2 = new customer("test2",3559,20000);



        bank newbank = new bank();
        account newaccount = new account();
        newaccount.addaccount(newcustomer);
        newaccount.addaccount(newcustomer2);
        for(int i = 0; i<newaccount.account.size();++i){
            System.out.println(newaccount.account.get(i));
        }//account number verification














        while (choice != 7){

            System.out.println("1) Make a deposit");//works partially doesn't fully transfer
            System.out.println("2) Make a withdrawal");//works partially doesn't fully transfer
            System.out.println("3) See account balance");//works
            System.out.println("4) Close account");//works
            System.out.println("5) add account");//works
            System.out.println("6) close all account");//works
            System.out.println("7) Exit");//works
            System.out.println("");

            choice = Integer.parseInt(scanner.nextLine());

            if(choice == 1){
                System.out.println("Enter PIN");
                pin = Integer.parseInt(scanner.nextLine());
                System.out.println("Enter Name");
                name = scanner.nextLine();
                System.out.println("Enter balance");
                balance = Integer.parseInt(scanner.nextLine());

                    System.out.println("Enter enter amount");
                    entry = Integer.parseInt(scanner.nextLine());
                    newbank.deposit(newaccount.verify(pin,name,balance),entry);






            } else if (choice ==2) {

                System.out.println("Enter PIN");
                pin = Integer.parseInt(scanner.nextLine());
                System.out.println("Enter name");
                name = scanner.nextLine();
                System.out.println("Enter balance");
                balance = Integer.parseInt(scanner.nextLine());

                    System.out.println("Enter enter amount");
                    entry = Integer.parseInt(scanner.nextLine());
                    newbank.withdrawl(newaccount.verify(pin,name,balance),entry);

            } else if (choice == 3) {
                System.out.println("Enter PIN");
                pin = Integer.parseInt(scanner.nextLine());
                System.out.println("Enter name");
                name = scanner.nextLine();
                System.out.println("Enter balance");
                balance = Integer.parseInt(scanner.nextLine());
                newaccount.verify(pin,name,balance);




            } else if (choice == 4) {
                System.out.println("Enter PIN");
                pin = Integer.parseInt(scanner.nextLine());
                System.out.println("Enter name");
                name = scanner.nextLine();
                System.out.println("Enter balance");
                balance = Integer.parseInt(scanner.nextLine());
                newaccount.removeaccount(newaccount.verify(pin,name,balance));
                for(int i = 0; i<newaccount.account.size();++i){
                    System.out.println(newaccount.account.get(i));
                }//double checks



            } else if (choice == 5) {
                System.out.println("Enter PIN");
                pin = Integer.parseInt(scanner.nextLine());
                System.out.println("Enter balance");
                balance = Integer.parseInt(scanner.nextLine());
                System.out.println("Enter name");
                name = scanner.nextLine();
                customer custom = new customer(name,pin,balance);
                newaccount.addaccount(custom);
                System.out.println("account added");
                newaccount.getaccount(custom);


            } else if (choice == 6) {
                newaccount.account.clear();
                for(int i = 0; i<newaccount.account.size();++i){
                    System.out.println(newaccount.account.get(i));
                    System.out.println(newaccount.account.get(i));
                }
                System.out.println("all accounts cleared");

            }




        }





        scanner.close();


    }

}


