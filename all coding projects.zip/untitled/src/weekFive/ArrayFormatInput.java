package weekFive;

import javax.swing.*;

public class ArrayFormatInput {
    public static void main(String[] args){
        String [] Student_names = new String[3];
        int [] Student_ages = new int[3];
        double [] Student_grades = new double[3];


        for(int i = 0; i<3; ++i){
            String names = JOptionPane.showInputDialog(null,"Enter students name:");
            Student_names[i] = names;
            int ages =Integer.parseInt(JOptionPane.showInputDialog(null,"Enter students age:"));
            Student_ages[i] = ages;
            int grades =Integer.parseInt(JOptionPane.showInputDialog(null,"Enter students grades(numbers like 87:)"));
            Student_grades[i] = grades;



        }
        for (int j = 0; j < Student_names.length; j++){
            System.out.printf(Student_names[j]+ "   "+Student_ages[j]+"   "+Student_grades[j]+"  ");



        }
    }

}
