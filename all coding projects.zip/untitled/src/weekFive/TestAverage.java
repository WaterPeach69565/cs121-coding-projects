package weekFive;

import javax.swing.*;
import java.util.ArrayList;

public class TestAverage {
    public static void main(String[] args){
        int number_of_students =Integer.parseInt(JOptionPane.showInputDialog("Enter the number of students"));
        ArrayList<Integer> grades_list = new ArrayList<Integer>();
       int sum = 0;
       int avg;


        for (int j = 0; j<1; j++){
            for(int i = 0; i < number_of_students; i++){
                int grades =Integer.parseInt(JOptionPane.showInputDialog("Enter the grades in number"));
                grades_list.add(grades);
            }
            for(int a : grades_list){
                sum += a;

            }
        }

     
        avg = sum / grades_list.size();
        System.out.println(avg);













    }

}
