package weekFive.LabFive;

import javax.swing.*;

public class HotelOccupancy {
    public static void main(String[] args){
      int number_floors = Integer.parseInt(JOptionPane.showInputDialog(null,"enter the number of floors"));
      int total_rooms = 0;
      int total_occupied = 0;
      int total_vacancy;
      double occupancyrate;
      for(int i = 1; i <= number_floors ; i++){
          int rooms = Integer.parseInt(JOptionPane.showInputDialog(null,"enter the number of rooms on the floor"));
          System.out.println("total rooms: "+rooms);
          int occupied = Integer.parseInt(JOptionPane.showInputDialog(null,"how many are occupied"));
          System.out.println("rooms occupied: "+occupied);
          total_rooms = rooms + total_rooms;
          total_occupied = occupied + total_occupied;

      }
      total_vacancy = total_rooms - total_occupied;
      System.out.println("Vacant rooms:" + total_vacancy);
      occupancyrate = (double)total_occupied / total_rooms;
      System.out.println("We are at "+occupancyrate*100+"% occupancy");



    }
}
