package weekFive;

import javax.swing.*;
import java.util.Arrays;

public class CopyArray {
    public static void main(String[] args){
        int[] array_1 = {0,0,0,0,0};
        int[] array_2 = {0,0,0,0,0};
        int[] array_3 = {0,0,0,0,0};
        int[] array_4 = {0,0,0,0,0};
        for(int i = 0; i<5; ++i){
            int array_entry = Integer.parseInt(JOptionPane.showInputDialog(null,"enter a number"));
            array_1[i] = array_entry;

        }
        for(int i = 0; i<5; ++i){
            array_2[i] = array_1[i];


        }
        for(int i = 0; i<array_1.length; ++i){
            array_3[i] = array_1[array_1.length -1 -i];





        }
        for(int i = 0; i<array_1.length; ++i){
            array_4[i] = (int)Math.pow(array_1[i],2);


        }


        System.out.println("The original array");
        System.out.println(Arrays.toString(array_1));
        System.out.println("Copy of the original array");
        System.out.println(Arrays.toString(array_2));
        System.out.println("Reverse of the original array");
        System.out.println(Arrays.toString(array_3));
        System.out.println("The original array squared");
        System.out.println(Arrays.toString(array_4));


    }
}
