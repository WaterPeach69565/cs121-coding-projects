package weekTwelve;

import javax.swing.*;

public class additems {
    private String items;

    public String getItems(String items) {
        System.out.println("Enter item");
        items = JOptionPane.showInputDialog(null,"");
        System.out.println("Item added");

        return items;
    }
}
