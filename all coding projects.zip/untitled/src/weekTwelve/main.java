package weekTwelve;

public class main {
    static public void main(String args[]){
        Datastructer ds = new Datastructer();
        ds.addage(30);
        ds.printage();
        ds.removeage();
        System.out.println("Ages cleared");
       ds.printage();
       ds.addname("Drew");
        ds.printname();
        ds.removename();
        System.out.println("Names cleared");
        ds.printname();


        ds.addmajor("Computer Science",3.2);
        ds.printmajorgpa();

        ds.addhmetown("Fishers");
        ds.addhmstate("Indiana");
        ds.addnationality("American");
        ds.printstate();
        ds.printtown();
        ds.printnationality();
        ds.printmajorgpa();

       ds.removemadjor();
       ds.removenationality();
       ds.removestate();
       ds.removetown();


    }
}
