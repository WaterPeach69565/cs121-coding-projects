package weekTwelve;

import java.util.Stack;

public class stacks {
    public static void main(String args[]){
        Stack<String>demo = new Stack<>();

    }

}
