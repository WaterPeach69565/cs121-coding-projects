package weekTwelve;

import java.util.*;

public class Datastructer {
    private ArrayList<String> studentlist = new ArrayList<>();
    private int ageindex = 0;
    private int[] agelist = new int[3];
    private HashMap<String, Double> majorgpd = new HashMap<>();
    private LinkedList<String> nationalitylist = new LinkedList<>();
    private Stack<String> hometownstack = new Stack<>();
    private Queue<String> homestatequeue = new LinkedList<>();
//adding methods//
    public void addname(String s){
      studentlist.add(s);
    }
    public void addage(int age){
        if(ageindex<agelist.length){
            agelist[ageindex ++] = age;
        }
    }
    public void addmajor(String major, double gpa){
        majorgpd.put(major,gpa);
        System.out.println("Information logged");
    }
    public void addnationality(String nationality){
        nationalitylist.add(nationality);
    }
    public void addhmetown(String home){
      hometownstack.add(home);
    }
    public void addhmstate(String state){
        homestatequeue.add(state);
    }
//removing methods//
    public void removeage(){
        if(ageindex > 0){
            agelist[-- ageindex] = 0;
        }
    }
    public void removename(){
    studentlist.clear();

    }   public void removemadjor(){
        majorgpd.clear();
    }
    public void removenationality(){
       nationalitylist.clear();
    }
    public void removetown(){
        hometownstack.clear();
    }
    public void removestate(){
        homestatequeue.clear();
    }

//displaying methods//
    public void printage(){
        for(int i = 0; i<agelist.length; i++){
            System.out.println(agelist[i]);
        }
    }
    public void printname(){
        for(int i = 0; i<studentlist.size(); i++){
            System.out.println(studentlist.get(i));
        }
    }
    public void printmajorgpa(){
        majorgpd.forEach((key,value)->{
            System.out.println("Key:"+key +"\nValue:" + value);
        });
       /* for(int i = 0; i<majorgpd.size(); i++){
            System.out.println(majorgpd);
            System.out.println(majorgpd.get(i));
           // System.out.println(Arrays.asList(majorgpd.get(i)));


        }

        */
    }
    public void printnationality(){
        for(int i = 0; i<nationalitylist.size(); i++){
            System.out.println(nationalitylist.get(i));
        }
    }
    public void printtown(){
        for(int i = 0; i<hometownstack.size(); i++){
            System.out.println(hometownstack.get(i));
        }
    }
    public void printstate(){
        for(int i = 0; i<homestatequeue.size(); i++){
            System.out.println(homestatequeue.peek());
        }

    }

}
