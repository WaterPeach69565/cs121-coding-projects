package weekTwelve;

import java.util.Stack;

public class test {
    public static void main(String args[]){

        recentcounter recentcounter = new recentcounter();
        ValidParenthesis vp = new ValidParenthesis();
        System.out.println(vp.isvalid("({[]})"));


        System.out.println(recentcounter.ping(1));
        System.out.println(recentcounter.ping(1001));
        System.out.println(recentcounter.ping(3001));
        System.out.println(recentcounter.ping(3002));

    }
}
