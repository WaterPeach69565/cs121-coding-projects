package weekTwelve;

import javax.swing.*;

public class displayitems {
    private String items;

    public void displayitems(String items) {
     System.out.println(items);
    }
}
