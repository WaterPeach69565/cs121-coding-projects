package weekTwelve;

import java.util.HashSet;
import java.util.Set;

public class sets {
public static void main(String args[]){
    Set<String> items = new HashSet<>();
    String item = null;
    String item2 = null;
    additems additem = new additems();
    displayitems displayitem = new displayitems();

    items.add(additem.getItems(item));
    displayitem.displayitems(items.toString());

    



}
}
