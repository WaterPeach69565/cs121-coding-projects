package weekFourteen;

import static weekFourteen.recursion.countdown;
import static weekFourteen.recursion.reversealphabet;

public class recursiontest {
    public static void main(String args[]){

        countdown(10);
        reversealphabet('z');



    }
}
