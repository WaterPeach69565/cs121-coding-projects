package weekEleven;

import javax.swing.*;
import java.io.*;
import java.util.Scanner;

public class FileAppend {
    public static void main(String args[])throws IOException {

        try{
            FileWriter fileoutput = new FileWriter("Testingfilewrite.txt",true);
            PrintWriter output = new PrintWriter(fileoutput);
            String name = JOptionPane.showInputDialog(String.format("Enter User name"));

            

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }



    }
}
