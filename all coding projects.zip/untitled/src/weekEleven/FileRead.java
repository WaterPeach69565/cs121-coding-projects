package weekEleven;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class FileRead {
    public static void main(String args[])throws FileNotFoundException {
        File fileoutput = new File("Testingfilewrite.txt");

        try{
            Scanner console = new Scanner(fileoutput);
            String header = console.nextLine();
            System.out.printf(header);



            console.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }


    }
}
