package weekEleven;
import javax.swing.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class FileWrite{
    public static void main(String args[]) throws FileNotFoundException{
        File outfile = new File("Testingfilewrite.txt");
        PrintWriter output = new PrintWriter(outfile);


        String name, password, playerCharacter;
        int score ;
        double winningPercent ;


        for(int i = 0; i < 2 ; i++){
            name = JOptionPane.showInputDialog(String.format("Enter User name"));
            password = JOptionPane.showInputDialog(String.format("Enter  password"));
            playerCharacter = JOptionPane.showInputDialog(String.format("Enter  character"));
            score = Integer.parseInt(JOptionPane.showInputDialog(String.format("Enter  health")));
            winningPercent = Double.parseDouble(JOptionPane.showInputDialog(String.format("Enter winning percent")));
            output.printf(name,password,score,playerCharacter,winningPercent);


        }
        output.close();


    }

}
