package weekEleven.ProjectEleven;

import java.util.ArrayList;

public class Pokedex {
    private ArrayList<Pokemon>pokemonArrayList = new ArrayList<>();

    public Pokedex(){}
    public void addPokemon (Pokemon pokemon){
        pokemonArrayList.add(pokemon);
    }
    public void removePokemon (Pokemon pokemon){
        pokemonArrayList.remove(pokemon);
    }

    public ArrayList<Pokemon> getPokemonArrayList() {
        return pokemonArrayList;
    }
    public Pokemon getPokemon(String pokemonname){
        Pokemon foundpokemon = null;
        for(Pokemon pokemon : pokemonArrayList){
            if (pokemon.getName().equals(pokemonname)){
                foundpokemon = pokemon;
                break;
            }
        }
        return foundpokemon;
    }
}
