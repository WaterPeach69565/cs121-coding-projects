package weekEleven.ProjectEleven;

import java.util.ArrayList;

public class Pokemon {
    private String name;
    private int hp;
    private ArrayList<move> moveArrayList = new ArrayList<>();
    public Pokemon(String name, int hp){
        this.name = name;
        this.hp = hp;
    }
    public String getName(){
        return name;
    }
    public int getHp(){
        return hp;
    }

    public ArrayList<move> getMoveArrayList() {
        return moveArrayList;
    }
    public void addmove(move Move){
        moveArrayList.add(Move);
    }
    public void removemove(move Move){
        moveArrayList.remove(Move);
    }
    public ArrayList<move> getallmoves(){
        return moveArrayList;
    }
    public move getmove(String movename){
        move foundmove = null;
        for(move Move : moveArrayList){
            if (Move.getMoveName().equals(movename)){
                foundmove = Move;
                break;
            }
        }
        return foundmove;
    }
    @Override
    public String toString(){
        return String.format(name+","+hp+",");
    }
}
