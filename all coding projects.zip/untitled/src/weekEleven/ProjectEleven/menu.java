package weekEleven.ProjectEleven;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.swing.*;


public class menu {
    static Scanner scanner = new Scanner(System.in);
    public static void main(String args[]) throws IOException {
        File outfile = new File("CharacterStatsFile.txt");
        PrintWriter output = new PrintWriter(new FileWriter(outfile,true));
        int choice = 0;
        int hp = 0;
        int power = 0;
        int speed = 0;
        String name = "null";
        String info = "null";







       while (choice != 5){

           System.out.println("1) Add Pokemon");
           System.out.println("2) Remove Pokemon");
           System.out.println("3) Display Pokemon info");
           System.out.println("4) Display all Pokemon");
           System.out.println("5) Exit");
           System.out.println("");
           choice = Integer.parseInt(scanner.nextLine());

           if(choice == 1){

               System.out.println("Enter Pokemon name");
               name = scanner.nextLine();
               System.out.println("Enter HP");
               hp = Integer.parseInt(scanner.nextLine());
               System.out.println("Enter move name");
               info = scanner.nextLine();
               System.out.println("Enter move power");
               power = Integer.parseInt(scanner.nextLine());;
               System.out.println("Enter move accuracy");
               speed = Integer.parseInt(scanner.nextLine());
               move Move = new move(info,power,speed);
               Pokemon pokemon = new Pokemon(name,hp);
               output.printf(String.valueOf(pokemon)+" "+Move);
               System.out.println("Pokemon added please relaunch Pokedex to see newly added Pokemon");





           } else if (choice ==2) {
               try {
                   File myObj = new File("CharacterStatsFile.txt");
                   Scanner myReader = new Scanner(myObj);
                   name = scanner.nextLine();
                   List<String> list = new ArrayList<>();
                   while (myReader.hasNextLine()) {
                       list.add(myReader.nextLine());
                   }
                   if(list.contains(name)){
                       output.append(name);
                   }

                   myReader.close();
               } catch (FileNotFoundException e) {
                   System.out.println("An error occurred.");
                   e.printStackTrace();
               }



           } else if (choice == 3) {

               try {
                   File myObj = new File("CharacterStatsFile.txt");
                   Scanner myReader = new Scanner(myObj);
                   name = scanner.nextLine();
                   List<String> list = new ArrayList<>();
                   while (myReader.hasNextLine()) {
                       list.add(myReader.nextLine());
                   }
                   if(list.contains(name)){
                       System.out.println("Pokemon found");
                       System.out.println(name);

                   } else {
                       System.out.println("Pokemon not found");
                   }
                   myReader.close();
               } catch (FileNotFoundException e) {
                   System.out.println("An error occurred.");
                   e.printStackTrace();
               }




           } else if (choice == 4) {

               try {
                   File myObj = new File("CharacterStatsFile.txt");
                   Scanner myReader = new Scanner(myObj);
                   while (myReader.hasNextLine()) {
                       String data = myReader.nextLine();
                       System.out.println(data);
                   }
                   myReader.close();
               } catch (FileNotFoundException e) {
                   System.out.println("An error occurred.");
                   e.printStackTrace();
               }



           }




       }



        scanner.close();
       output.close();

    }

}
