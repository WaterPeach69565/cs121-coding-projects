package weekEleven.ProjectEleven;

public class move {
   private String moveName;
   private int movePower;
   private int moveaccuracy;
    public move(String moveName, int movePower, int moveaccuracy) {
        this.moveName = moveName;
        this.movePower = movePower;
        this.moveaccuracy = moveaccuracy;


}
    public String getMoveName(){
        return moveName;
    }
    public int getMovePower(){
        return movePower;
    }
    public int getMoveaccuracy(){
        return moveaccuracy;
    }
    @Override
    public String toString(){
        return String.format(moveName+","+ moveaccuracy +","+movePower);
    }



}
