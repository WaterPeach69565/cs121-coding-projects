package weekFour;

import javax.swing.*;

public class GuessingGame {
    static public void main(String[] args){
        String quit = "None";
        String start = "None";
        int number = (int)(Math.random() * 101);
        int numberofguesses = 3;
        int guessednumber = 0;
        int rangenumber = 0;
        System.out.println(number);
        start = JOptionPane.showInputDialog("would you like to play enter q if you would like to quit:");

        if(start.equals("q")){
            JOptionPane.showMessageDialog(null,"game quit the number was: "+number);



        }else { while (quit.equals("None")){
            guessednumber = Integer.parseInt(JOptionPane.showInputDialog("Enter a number between 1 and 100"));
            if(guessednumber == number){


                JOptionPane.showMessageDialog(null,"Correct the number was: "+number+" remaining tries: "+numberofguesses);
                quit = "correct";



            }else{
                numberofguesses = numberofguesses - 1;

                if(guessednumber>number){
                    rangenumber = guessednumber - number;
                    JOptionPane.showMessageDialog(null,"your guess was greater than the number. Number of tries remaining: "+numberofguesses);
                    //JOptionPane.showMessageDialog(null,"Incorrect number is: "+rangenumber+" off remaining tries: "+numberofguesses);

                } else if (guessednumber<number) {
                    rangenumber =  number - guessednumber;
                    JOptionPane.showMessageDialog(null,"your guess was smaller than the number. Number of tries remaining: "+numberofguesses);
                    //JOptionPane.showMessageDialog(null,"Incorrect number is: "+rangenumber+" off remaining tries: "+numberofguesses);

                }


            }

            if(numberofguesses == 0){
                quit = "failed";
                JOptionPane.showMessageDialog(null,"Out of guesses");
            }}
// finished at 10:26







        }



    }

}
