package weekFour;

import javax.swing.*;

public class DistanceTraveled {
    static public void main(String[] args){
        double speed;
        int time;
        double distance;

        speed = Integer.parseInt(JOptionPane.showInputDialog("Enter the current speed"));
        time = Integer.parseInt(JOptionPane.showInputDialog("Enter how many hours its been"));

        for (int i = -time; i < time; i++){

            distance = speed * time;
            time = time - 1;
            System.out.println(distance);


        }






    }

}
//finished 10:32