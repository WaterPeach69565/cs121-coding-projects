package weekFour.LabFour;

import javax.swing.*;

public class ESPGame {
    public static void main(String[] args){

        int number_of_round = 10;
        String guess;
        int correct_guess = 0;


        while(number_of_round > 0){
            String number_color = "null";
            int number = (int)(Math.random() * 5);
            System.out.println(number);
            guess = JOptionPane.showInputDialog(null,"Enter a color red, green, blue, orange, or yellow:");
            if(number == 0){
                number_color = "red";

            } else if (number == 1) {
                number_color = "green";

            } else if (number == 2) {
                number_color = "blue";

            } else if (number == 3) {
                number_color = "orange";

            }else if (number == 4){
                number_color = "yellow";

            }
            if (guess.equals(number_color)){
                correct_guess = correct_guess +1;


            }else {
                System.out.println("Incorrect");

            }


            number_of_round = number_of_round - 1;


        }
        System.out.println(correct_guess);
        JOptionPane.showMessageDialog(null,"You got: "+correct_guess+" out of 10");






    }
}
