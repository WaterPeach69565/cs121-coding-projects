package weekFour;

import javax.swing.*;

public class CFTable {
    public static void main(String[] args){
       double celcius = 0;
       double fahranheit;
       int [] list = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20};


       for (int i : list){
           celcius = i;
           fahranheit = (celcius * 9/5) + 32;
           System.out.println(fahranheit);


       }




    }
}
// finished 10:20