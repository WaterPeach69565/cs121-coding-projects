package ProjectOne;

import javax.swing.*;

public class CharacterBattle {
    public static void main(String[] args){
        int player_1 = 100;
        int player_2 = 100;
        int player_1_speed = (int)(Math.random() * 101);
        int player_2_speed = (int)(Math.random() * 101);
        System.out.println(player_1_speed);
        System.out.println(player_2_speed);
        String player_1_name;
        String player_2_name;
        int speed = 0;
        int damage = 0;
        String player_1_attack;
        String player_2_attack;
        String game_ender = "c";
        int number_of_rounds = Integer.parseInt(JOptionPane.showInputDialog(null,"Enter an odd number of rounds"));
        int player_1_score=0;
        int player_2_score=0;

        if (number_of_rounds % 2 == 0){
            System.out.println(number_of_rounds + " is even please enter an odd number on restart");


        }
        else {
            System.out.println("the number is odd");



            player_1_name = JOptionPane.showInputDialog("Enter player 1 name:");
            player_2_name = JOptionPane.showInputDialog("Enter player 2 name:");






            if(player_1_name.equals("") && player_2_name.equals("")){

                JOptionPane.showMessageDialog(null,"No names selected");




            }else{
                if(player_1_speed == player_2_speed){
                    player_1_speed = (int)(Math.random() * 101);
                    player_2_speed = (int)(Math.random() * 101);
                    System.out.println(player_1_speed);
                    System.out.println(player_2_speed);



                }


                while(number_of_rounds > 0){

                    if (player_1_speed > player_2_speed){

                        player_1_attack = JOptionPane.showInputDialog(player_1_name+"Enter either jab = 10,kick = 30, or hook = 60 (this is case sensitive so enter it as shown):");


                        if (player_1 <= 0){
                            player_2_score = player_2_score+1;
                            player_1 = 100;
                        } else if (player_2 <= 0) {
                            player_1_score = player_1_score+1;
                            player_2 = 100;
                        }


                        if(player_1_attack.equals("jab")){

                            damage = 10;
                            player_2 = player_2 - damage;

                        } else if (player_1_attack.equals("kick")) {

                            damage = 30;
                            player_2 = player_2 - damage;

                        } else if (player_1_attack.equals("hook")) {

                            damage = 60;
                            player_2 = player_2 - damage;

                        } else if (player_1_attack.equals("debug")) {
                            damage = 100;
                            player_2 = player_2 - damage;


                        }

                        if (player_1 <= 0){
                            player_2_score = player_2_score+1;
                            player_1 = 100;
                        } else if (player_2 <= 0) {
                            player_1_score = player_1_score+1;
                            player_2 = 100;
                        }
                        System.out.println(player_1_attack);


                        player_2_attack = JOptionPane.showInputDialog(player_2_name+"Enter either jab = 10,kick = 30, or hook = 60 (this is case sensitive so enter it as shown):");

                        System.out.println(player_2);
                        if(player_2_attack.equals("jab")){

                            damage = 10;
                            player_1 = player_1 - damage;

                        } else if (player_2_attack.equals("kick")) {

                            damage = 30;
                            player_1 = player_1 - damage;

                        } else if (player_2_attack.equals("hook")) {

                            damage = 60;
                            player_1 = player_1 - damage;

                        } else if (player_2_attack.equals("debug")) {

                            damage = 100;
                            player_1 = player_1 - damage;

                        }
                        number_of_rounds = number_of_rounds - 1;
                        System.out.println(number_of_rounds);



                    } else if ( player_2_speed > player_1_speed) {
                        player_2_attack = JOptionPane.showInputDialog(player_2_name+" Enter either jab = 10,kick = 30, or hook = 60 (this is case sensitive so enter it as shown):");



                        if (player_1 <= 0){
                            player_2_score = player_2_score+1;
                            player_1 = 100;
                        } else if (player_2 <= 0) {
                            player_1_score = player_1_score+1;
                            player_2 = 100;
                        }


                        if(player_2_attack.equals("jab")){

                            damage = 10;
                            player_1 = player_1 - damage;

                        } else if (player_2_attack.equals("kick")) {

                            damage = 30;
                            player_1 = player_1 - damage;

                        } else if (player_2_attack.equals("hook")) {

                            damage = 60;
                            player_1 = player_1 - damage;

                        } else if (player_2_attack.equals("debug")) {
                            damage = 100;
                            player_1 = player_1 - damage;


                        }

                        if (player_1 <= 0){
                            player_2_score = player_2_score+1;
                            player_1 = 100;
                        } else if (player_2 <= 0) {
                            player_1_score = player_1_score+1;
                            player_2 = 100;
                        }
                        player_1_attack = JOptionPane.showInputDialog(player_1_name+" Enter either jab = 10,kick = 30, or hook = 60 (this is case sensitive so enter it as shown):");

                        System.out.println(player_2);
                        if(player_1_attack.equals("jab")){

                            damage = 10;
                            player_2 = player_2 - damage;

                        } else if (player_1_attack.equals("kick")) {

                            damage = 30;
                            player_2 = player_2 - damage;

                        } else if (player_1_attack.equals("hook")) {

                            damage = 60;
                            player_2 = player_2 - damage;

                        } else if (player_1_attack.equals("debug")) {

                            damage = 100;
                            player_2 = player_2 - damage;

                        }
                        number_of_rounds = number_of_rounds - 1;
                        System.out.println(number_of_rounds);

                    }


                    System.out.println(player_1);

                }




            }




            if (player_1_score > player_2_score){
                JOptionPane.showMessageDialog(null,player_1_name+" is the winner with a score of: "+ player_1_score);


            } else {
                JOptionPane.showMessageDialog(null,player_2_name+" is the winner with a score of :" + player_2_score);

            }
        }}


}
