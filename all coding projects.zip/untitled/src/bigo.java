public class bigo {
    public static void main(String args[]){


printonetime("scrim");
    }
    public static void printonetime(String name){
        System.out.println(name);
    }
}
