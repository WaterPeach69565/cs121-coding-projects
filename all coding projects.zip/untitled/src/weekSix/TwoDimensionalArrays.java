package weekSix;

import java.util.Arrays;

public class TwoDimensionalArrays {
    public static void main(String[] args){
        int[][] array_1 = {{1,2,3},{4,5,6},{7,8,9},{10,11,12}};
        double [] list_1 ={1.1,2.2,3.3};
        double [] list_2 ={4.4,5.5,6.6};
        double [] list_3 ={7.7,8.8,9.9};
        double [][] array_2 = new double [3][3];
        //double [][] array_2 = {{0,0,0},{0,0,0},{0,0,0}};
        // 0   1   2   3
        // 0   1   2   3
        // 0   1   2   3
        // 1.1
        //             6.6
        //array_2[0][0]=1.1;

        //array_2[1][3] = 6.6;
        for(double[] row: array_2){
            for(int i = 0;i< row.length;i++){

                for(int j = 0; j<list_1.length;j++){
                    array_2[0][j]=list_1[j];


                }
                for(int k = 0; k<list_1.length;k++){
                    array_2[1][k]=list_2[k];

                }
                for(int l = 0; l <list_1.length; l++){
                    array_2[2][l]=list_3[l];

                }






            }


        }


        for(int i = 0;i<array_1.length;i++){
            System.out.println(Arrays.toString(array_1[i]));



        }
        for(int g = 0; g<array_2.length;g++){
            System.out.println(Arrays.toString(array_2[g]));
        }

    }
}
