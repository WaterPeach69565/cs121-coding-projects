package weekSix.LabSix;

import java.util.Scanner;

public class Rectangle {
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args){
        double length,width,area;
        length = getlength();
        width = getwidth();
        area = getArea(length,width);

        display_data(length,width,area);




        scanner.close();
    }
    public static double getlength(){
        System.out.println("Enter the length of the rectangle");
        double getLength = scanner.nextInt();




        return getLength;
    }
    public static double getwidth(){
        System.out.println("Enter the width of the rectangle");
        double getWidth = scanner.nextInt();




        return getWidth;
    }
    public static double getArea(double length, double width){
        double area = length * width;





        return area;
    }
    public static void display_data(double length, double width, double area){
        System.out.println("Length: "+length);
        System.out.println("Width: "+width);
        System.out.println("The area of the rectangle is: "+area);

    }
}
