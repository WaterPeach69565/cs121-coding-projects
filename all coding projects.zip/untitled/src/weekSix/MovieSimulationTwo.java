package weekSix;

import java.util.Arrays;
import java.util.Scanner;

public class MovieSimulationTwo {
    final static int NUM_OF_ROWS = 5;
    final static int NUM_OF_COLUMNS = 10;
    static Scanner scanner = new Scanner(System.in);
    public static void main(String[] args){





        String[] movieNames = {"Spirited Away","Toy Story","Howls Moving Castle","Cars"};
        String[] movieType = {"2D","3D","2D","3D"};

        double[] moviePrice = {9.99,10.99,9.99,10.99};
        int[][] movieAvailablity = new int[NUM_OF_ROWS][NUM_OF_COLUMNS];
        System.out.println("Standard seats");
        seat_chart(movieAvailablity);


        System.out.println("Randomized seats 0 is available and 1 is taken");
        seat_chart_random(movieAvailablity);



        System.out.println("-------------------------Movie details-------------------------");
        System.out.println("Movie Name          Movie Type                Movie Price");
        for(int i = 0; i<movieNames.length; i++){
            System.out.println("Movie "+i+": "+movieNames[i]+"   "+movieType[i]+"   "+"   $"+moviePrice[i]);


        }



    }    public static int[][] seat_chart(int [][] movieAvailablity){

        for (int i = 0; i < NUM_OF_ROWS; i++){
            for(int j = 0; j<movieAvailablity[i].length;j++){
                movieAvailablity[i][j] = 0;
                System.out.print(movieAvailablity[i][j] + " ");


            }




        }


        return movieAvailablity;

    }
    public static int[][] seat_chart_random(int [][] movieAvailablity){

        for (int i = 0; i < NUM_OF_ROWS; i++){
            for(int j = 0; j<movieAvailablity[i].length;j++){
                movieAvailablity[i][j] = (int)(Math.random()*2);
                System.out.print(movieAvailablity[i][j] + " ");


            }




        }


        return movieAvailablity;

    }


}
