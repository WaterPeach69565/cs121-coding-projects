package weekSix;

import javax.swing.*;

public class MovieSimulationOne {
    public static void main(String[] args){
        int numofmovie = Integer.parseInt(JOptionPane.showInputDialog(null,"enter the number of movies"));



        String[] movieNames = new String[numofmovie];
        String[] movieType = new String[numofmovie];
        int[] movieAvailablity = new int[numofmovie];
        float[] moviePrice = new float [numofmovie];

        for(int i = 0; i<movieNames.length;i++){
            String array_entry = (JOptionPane.showInputDialog(null,"enter the name of the movie"));
            movieNames[i] = array_entry;
            System.out.println(array_entry);


        }
        for(int i = 0; i<movieType.length;i++){
            String array_entry = (JOptionPane.showInputDialog(null,"enter the type of the movie (2D or 3D)"));
            movieType[i] = array_entry;
            System.out.println(array_entry);


        }
        for(int i = 0; i< movieAvailablity.length; ++i){
            int array_entry = Integer.parseInt(JOptionPane.showInputDialog(null,"enter the number of seats"));
            movieAvailablity[i] = array_entry;
            System.out.println(array_entry);

        }
        for(int i = 0; i<moviePrice.length; ++i){
            float array_entry = Float.parseFloat(JOptionPane.showInputDialog(null,"enter the price of the movie"));
            moviePrice[i] = array_entry;
            System.out.println(array_entry);

        }

        System.out.println("-------------------------Movie details-------------------------");
        System.out.println("Movie Name          Movie Type           Available Seats      Movie Price");
        for(int i = 0; i<numofmovie; i++){
            System.out.println("Movie "+i+": "+movieNames[i]+"   "+movieType[i]+"   "+ movieAvailablity[i]+"   $"+moviePrice[i]);


        }






    }
}
