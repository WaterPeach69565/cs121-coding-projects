package weekTwo;

import java.util.Scanner;
import javax.swing.JOptionPane;

//Scanner
public class ActivityOne {
    public static void main(String[] args){
        double A; //the amount after n years
        double P; //principle amount
        double r; //annual interest rate
        int n; //times interest compounds
        int t; //number of years


        P=Double.parseDouble(JOptionPane.showInputDialog("Enter principle amount"));
        Scanner scn = new Scanner(System.in);
        //scn.nextDouble();
        //scn.nextInt(); or Integer.parseInt(scn.nextLine)




        r = Double.parseDouble(JOptionPane.showInputDialog("Enter annual interest amount"))/100; //8



        n = Integer.parseInt(JOptionPane.showInputDialog("Enter the number of times the interest compounds")); //12



        t = Integer.parseInt(JOptionPane.showInputDialog("Enter the number of years")); //5



        A = P * Math.pow((1 + r/n),n * t);


        JOptionPane.showMessageDialog(null,String.format("After " + t + " years you will have: $ " +A));



    }
}
