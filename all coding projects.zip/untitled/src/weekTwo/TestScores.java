package weekTwo;

import javax.swing.*;

public class TestScores {
   static public void main(String[] args){

       int testscore_1;
       int testscore_2;
       int testscore_3;

      char finalscore_1 = 'U';
       char finalscore_2 = 'U';
       char finalscore_3 = 'U';
       testscore_1 = Integer.parseInt(JOptionPane.showInputDialog("Enter test score 1"));
       testscore_2 = Integer.parseInt(JOptionPane.showInputDialog("Enter test score 2"));
       testscore_3 = Integer.parseInt(JOptionPane.showInputDialog("Enter test score 3"));

       if(testscore_1 <=60){
           finalscore_1 = 'F';
       }
       if(testscore_1 >= 61 && testscore_1<= 69){
           finalscore_1 = 'D';
       }
       if(testscore_1 >= 70 && testscore_1<= 79){
           finalscore_1 = 'C';
       }
       if(testscore_1 >= 80 && testscore_1<= 89){
           finalscore_1 = 'B';
       }
       if(testscore_1 >= 90 && testscore_1<= 100){
           finalscore_1 = 'A';
       }
       if(testscore_2 <=60){
           finalscore_2 = 'F';
       }
       if(testscore_2 >= 61 && testscore_1<= 69){
           finalscore_2 = 'D';
       }
       if(testscore_2 >= 70 && testscore_1<= 79){
           finalscore_2 = 'C';
       }
       if(testscore_2 >= 80 && testscore_1<= 89){
           finalscore_2 = 'B';
       }
       if(testscore_2 >= 90 && testscore_1<= 100){
           finalscore_2 = 'A';
       }
       if(testscore_3 <=60){
           finalscore_3 = 'F';
       }
       if(testscore_3 >= 61 && testscore_1<= 69){
           finalscore_3 = 'D';
       }
       if(testscore_3 >= 70 && testscore_1<= 79){
           finalscore_3 = 'C';
       }
       if(testscore_3 >= 80 && testscore_1<= 89){
           finalscore_3 = 'B';
       }
       if(testscore_3 >= 90 && testscore_1<= 100){
           finalscore_3 = 'A';
       }
       JOptionPane.showMessageDialog(null,String.format("The score of test 1 is a : "+finalscore_1+testscore_1+" The score of test 2 is a : "+finalscore_2+testscore_2+" The score of test 3 is a : "+finalscore_3+testscore_3));


    }
}
//finished 10:22