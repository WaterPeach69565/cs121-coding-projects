package weekTwo;

import javax.swing.*;

public class BookClubPoints {
    static public void main(String[] args){
        int NB;
        int points = 0;
        NB = Integer.parseInt(JOptionPane.showInputDialog("Enter number of books"));


        if(NB < 1){
            points = 0;

        }
        if (NB == 1) {
            points = 5;
        }
        if (NB == 2) {
            points = 15;
        }
        if (NB == 3) {
            points = 30;
        }
        if (NB >= 4) {
            points = 60;
        }
        JOptionPane.showMessageDialog(null,String.format("The number of books purchased is: "+NB+" the total points gained are: "+points));


    }
}
//finished at 10:09