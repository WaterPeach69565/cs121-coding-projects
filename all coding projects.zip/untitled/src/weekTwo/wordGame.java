package weekTwo;

import javax.swing.*;

public class wordGame {
    public static void main(String[] args){
        String name;
        int age;
        String city;
        String college;
        String major;
        String ATA;
        String pet_name;


        name = JOptionPane.showInputDialog("Enter your name:");
        age = Integer.parseInt(JOptionPane.showInputDialog("Enter your age:"));
        city = JOptionPane.showInputDialog("Enter your city");
        college = JOptionPane.showInputDialog("Enter your college");
        major = JOptionPane.showInputDialog("Enter your major");
        ATA = JOptionPane.showInputDialog("Enter a type of animal");
        pet_name = JOptionPane.showInputDialog("Enter a pet name");

        String final_1 = "There once was a person named "+name+" who lived in "+city+". ";
        String final_2 = "At the age of "+age+" "+name+" went to college at "+college+". ";
        String final_3 = name+" graduated with a major in "+major+". ";
        String final_4 = "Then, "+name+" adopted a "+ATA+" named "+pet_name+". They both lived happily ever after.";

        System.out.println(final_1);
        System.out.println(final_2);
        System.out.println(final_3);
        System.out.println(final_4);
        JOptionPane.showMessageDialog(null,final_1+final_2+final_3+final_4);




    }







}
