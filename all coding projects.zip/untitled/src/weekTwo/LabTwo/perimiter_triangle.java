package weekTwo.LabTwo;

import java.util.Scanner;

public class perimiter_triangle {
    public static void main(String[] args){
        int P;
        Scanner myObject_B = new Scanner(System.in);
        Scanner myObject_A = new Scanner(System.in);
        Scanner myObject_C = new Scanner(System.in);
        int A = myObject_A.nextInt();
        int B =myObject_B.nextInt();
        int C =myObject_C.nextInt();




        P = A+B+C;
        System.out.println("The perimeter of the triangle is "+P+" with one side being "+A+" another side being "+B+" and the last side being "+C);

    }


}
