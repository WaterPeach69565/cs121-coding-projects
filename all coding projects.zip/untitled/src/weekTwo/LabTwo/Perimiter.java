package weekTwo.LabTwo;

import javax.swing.*;
import java.util.Scanner;

public class Perimiter {
    public static void main(String[] args) {
        int P;
        Scanner myObject_B = new Scanner(System.in);
        Scanner myObject_H = new Scanner(System.in);
        int B = myObject_B.nextInt();
        int H =myObject_H.nextInt();




        P = B + B + H + H;
        System.out.println("The perimeter of the rectangle is "+P+" with two sides being "+B+" and two sides being "+H);






    }
}
