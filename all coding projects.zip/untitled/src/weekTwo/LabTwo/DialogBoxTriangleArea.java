package weekTwo.LabTwo;

import javax.swing.*;

public class DialogBoxTriangleArea {
    public static void main(String[] args){
        int A;
        int B;
        int H;

        B = Integer.parseInt(JOptionPane.showInputDialog("Enter the Base length"));
        H = Integer.parseInt(JOptionPane.showInputDialog("Enter the Height Length"));

        A = (B*H)/2;
        JOptionPane.showMessageDialog(null,String.format("A triangle with the base of:"+B+" " + "The height of:"+H+" " + "has an area of:"+A));

    }
}
