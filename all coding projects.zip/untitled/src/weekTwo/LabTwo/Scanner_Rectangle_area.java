package weekTwo.LabTwo;

import javax.swing.*;
//uses dialog boxes
public class Scanner_Rectangle_area {
    public static void main(String[] args){
        int A;
        int B;
        int H;

        B = Integer.parseInt(JOptionPane.showInputDialog("Enter the Base length"));
        H = Integer.parseInt(JOptionPane.showInputDialog("Enter the Height Length"));



        A = B*H;
        JOptionPane.showMessageDialog(null,String.format("A rectangle with the base of:"+B+" " + "The height of:"+H+" " + "has an area of:"+A));

    }

}
