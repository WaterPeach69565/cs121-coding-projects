package ProjectTwo;

import java.util.Scanner;

public class RandomTestScores {

    static int [] passin = new int [4];
    static int [] scores = new int [4];
    static char [] grades = new char [4];


    static Scanner scanner = new Scanner(System.in);


    public static void main(String args[]){

        int average = 0;
        int highest = 0;
        int lowest = 0;
        for (int i = 0; i < scores.length; i++){
            scores[i] = getscores();

            grades[i] = getlettergrade(scores[i]);

        }
        for(int i = 0; i < scores.length;i++){
            highest = scores[i];
            passin[i] = highest;
        }
        for(int i = 0; i < scores.length;i++){
            lowest = scores[i];
            passin[i] = lowest;
        }
        for(int i = 0; i < scores.length;i++){
            average = scores[i];
            passin[i] = average;
        }


        System.out.println("_______________________________________________");
        int biggest_score = highest_score(highest);
        int smallest_score = lowest_score(lowest);
        int average_score = average_score(average);


        scanner.close();





    }

    public static int getscores() {
        System.out.println("Enter test scores:");
        int getscore = scanner.nextInt();
        return getscore;
    }
    public static char getlettergrade(int score) {
        char lettergrades = 'N';

        if(score <= 59){
            lettergrades = 'F';



        } else if (score >= 60 && score <= 69) {
            lettergrades = 'D';


        }else if (score >=70 && score <= 79) {
            lettergrades = 'C';


        }else if (score >=80 && score <= 89) {
            lettergrades = 'B';


        }else if (score >=90 && score <= 100) {
            lettergrades = 'A';


        }



        return lettergrades;

    }

    public static int highest_score(int highest){
        highest = passin[0];
        for(int i = 0; i<passin.length;i++){
            if (highest < passin[i]){
                highest = passin[i];

            }

        }
        int biggest_score = highest;
        System.out.println("The highest score was: "+biggest_score);
        return highest;
    }
    public static int lowest_score(int score){
        int lowest = passin[0];
        for(int i = 0; i<passin.length;i++){
            if (lowest > passin[i]){
                lowest = passin[i];

            }

        }
        int crashout = lowest;
        System.out.println("The lowest score was: "+crashout);
        return lowest;
    }
    public static int average_score(int score){
        int average = 0;
        int sum = 0;
        int length = passin.length;
        for(int i :passin){
           average += i;
        }
        sum = average/length;
        int crashout = sum;
        System.out.println("The average score was: "+crashout);
        for(int i = 0; i<grades.length;i++){
            System.out.println(scores[i]+" "+grades[i]);
        }
        return sum;
    }








}
