package ProjectTwo;

public class globalarrays {
    public int [] passin = new int[4];
}
