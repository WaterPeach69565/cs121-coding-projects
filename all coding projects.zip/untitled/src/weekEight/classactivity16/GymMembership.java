package weekEight.classactivity16;

public class GymMembership {
   String name;
  int age;
   String subscription;
    public GymMembership(String name, int age, String subscription){
        this.name = name;
        this.age = age;
        this.subscription = subscription;

    }

}
