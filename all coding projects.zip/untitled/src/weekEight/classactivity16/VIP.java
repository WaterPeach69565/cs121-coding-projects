package weekEight.classactivity16;

public class VIP {
 String [] VIP_name = {"Hamond","James","Charles"};
 int [] VIP_ID = {10002,10003,10004};


}
