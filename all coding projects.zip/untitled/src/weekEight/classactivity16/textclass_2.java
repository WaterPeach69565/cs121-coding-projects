package weekEight.classactivity16;

import java.util.Scanner;

public class textclass_2 {


    static Scanner scanner = new Scanner(System.in);
    public static void main(String args[]){


        scanner.close();


        GymMembership member_1 = new GymMembership("Drew",21,"Monthly");
        System.out.println(member_1.name);




    }

}
