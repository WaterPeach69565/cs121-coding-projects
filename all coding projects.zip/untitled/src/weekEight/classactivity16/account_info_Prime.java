package weekEight.classactivity16;

public class account_info_Prime {
    private String account_name = "drew";
    private String account_type = "(Standard)";

    private int account_ID = 10002;

    private int credit = 1000;
    private int deposit = 15000;
    public int getid_2() {
        return account_ID;
    }
    public String getname_2() {
        return account_name;
    }
    public String gettype_2() {
        return account_type;
    }
    public int getDeposit_2() {
        return deposit;
    }
    public int getCredit() {
        return credit;
    }





    public account_info_Prime(String name, String type, int ID,int depo,int credit){
        this.account_name = name;
        this.account_type = type;
        this.account_ID = ID;
        this.deposit = depo;
        this.credit = credit;



    }
    @Override
    public String toString() {
        return super.toString();
    }



}
