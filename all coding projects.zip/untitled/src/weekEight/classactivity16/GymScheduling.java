package weekEight.classactivity16;

public class GymScheduling {
    private String [] classes = {"Boxing","Swimming","BasketBall"};



}
