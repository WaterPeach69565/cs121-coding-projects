package weekEight.classactivity16;

public class account_infor {



    private String account_name = "drew";
        private String account_type = "(Standard)";

        private int account_ID = 10002;

        private int deposit = 15000;
    public int getid() {
        return account_ID;
    }
    public int getDeposit() {
        return deposit;
    }
    public String getname() {
        return account_name;
    }
    public String gettype() {
        return account_type;
    }





    public account_infor(String name,String type, int ID, int depos){
        this.account_name = name;
        this.account_type = type;
        this.account_ID = ID;
        this.deposit = depos;



    }
    @Override
    public String toString() {
        return super.toString();
    }



}
