package weekEight.classactivity16;

public class banking {
static public void main(String args[]){

    account_infor x = new account_infor("drew","Standard",10002,15000);
    System.out.println(x.getname());
    System.out.println(x.gettype());
    System.out.println(x.getid());
    System.out.println(x.getDeposit());
    account_info_Prime y = new account_info_Prime("drew","Perm",10002,15000,1000);
    System.out.println(y.getname_2());
    System.out.println(y.gettype_2());
    System.out.println(y.getid_2());
    System.out.println(y.getDeposit_2());
    System.out.println(y.getCredit());




}

}
