package weekEight.labeight;

public class student_2 {
    private  String studentname;
    private int studentid;
    private String major;
    public String getsName() {
        return studentname;
    }


    public void setsName(String newsName) {
        this.studentname = newsName;
    }
    public int getid() {
        return studentid;
    }

    public void setid(int newid) {
        this.studentid = newid;
    }
    public String getmajor() {
        return major;
    }


    public void setmajor(String newmajor) {
        this.major = newmajor;
    }



    public student_2(String name, int SID,String Major){
        this.studentname = name;
        this.studentid = SID;
        this.major = Major;

    }
}
