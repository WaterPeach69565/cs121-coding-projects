package weekEight.labeight;

import weekSeven.student;

public class test {
    public static void main(String args[]){

        person person_1 = new person("Hanna",20,"Female");
        student_2 student_1 = new student_2("drew",12334,"Computer science");
        System.out.print(student_1.getsName());
        System.out.print(student_1.getid());
        System.out.print(student_1.getmajor());

        System.out.print(person_1.getName());
        System.out.print(person_1.getage());
        System.out.print(person_1.getsex());
    }




}
