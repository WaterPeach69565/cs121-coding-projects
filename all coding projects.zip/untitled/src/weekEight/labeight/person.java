package weekEight.labeight;

public class person {
    private String name = "Drew";
    private int age = 21;
   private String sex = "male";
    public String getName() {
        return name;
    }


    public void setName(String newName) {
        this.name = newName;
    }
    public int getage() {
        return age;
    }

    public void setage(int newage) {
        this.age = newage;
    }
    public String getsex() {
        return sex;
    }


    public void setsex(String newsex) {
        this.sex = newsex;
    }

    public person(String name, int age, String sex){
        this.name = name;
        this.age = age;
        this.sex = sex;

    }
}
