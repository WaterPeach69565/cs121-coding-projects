package weekSeven;

import javax.swing.*;
import java.util.Scanner;

public class MovieSimulation3 {
    final static int NUM_OF_ROWS = 5;
    final static int NUM_OF_COLUMNS = 10;
    static Scanner scanner = new Scanner(System.in);
    public static void main(String[] args){









        String[] movieNames = {"Spirited Away","Toy Story","Howls Moving Castle","Cars"};
        String[] movieType = {"2D","3D","2D","3D"};



        double[] moviePrice = {9.99,10.99,9.99,10.99};
        int[][] movieAvailablity = new int[NUM_OF_ROWS][NUM_OF_COLUMNS];



        System.out.println("Randomized seats 0 is available and 1 is taken");





        String User_input = JOptionPane.showInputDialog(null,"Enter a movie name");

        for(int s = 0; s<movieNames.length;s++){

            if(User_input.equalsIgnoreCase(movieNames[0])){

                System.out.println("-------------------------Movie details-------------------------");
                System.out.println("Movie Name          Movie Type                Movie Price");

                    System.out.println("Movie "+1+": "+movieNames[0]+"   "+movieType[0]+"   "+"   $"+moviePrice[0]);
                    System.out.print("Avaliable seats");
                    System.out.println();
                    seat_chart_random(movieAvailablity);
                    s = 5;




            }else if(User_input.equalsIgnoreCase(movieNames[1])){
                System.out.println("-------------------------Movie details-------------------------");
                System.out.println("Movie Name          Movie Type                Movie Price");

                System.out.println("Movie "+2+": "+movieNames[1]+"   "+movieType[1]+"   "+"   $"+moviePrice[1]);
                System.out.print("Avaliable seats");
                System.out.println();
                seat_chart_random(movieAvailablity);
                s = 5;

            } else if (User_input.equalsIgnoreCase(movieNames[2])) {
                System.out.println("-------------------------Movie details-------------------------");
                System.out.println("Movie Name          Movie Type                Movie Price");

                System.out.println("Movie "+3+": "+movieNames[2]+"   "+movieType[2]+"   "+"   $"+moviePrice[2]);
                System.out.print("Avaliable seats");
                System.out.println();
                seat_chart_random(movieAvailablity);
                s = 5;

            } else if (User_input.equalsIgnoreCase(movieNames[3])) {
                System.out.println("-------------------------Movie details-------------------------");
                System.out.println("Movie Name          Movie Type                Movie Price");

                System.out.println("Movie "+4+": "+movieNames[3]+"   "+movieType[3]+"   "+"   $"+moviePrice[3]);
                System.out.print("Avaliable seats");
                System.out.println();
                seat_chart_random(movieAvailablity);
                s = 5;

            }else {
                System.out.print("Movie not found");
            }


        }



    }
    public static int[][] seat_chart_random(int [][] movieAvailablity){
        for(int c = 1; c<= movieAvailablity[0].length; c++){
            System.out.printf(" %d",c);


        }
        System.out.println();
        char columnlabel[] = {'A','B','C','D','E'};

        System.out.printf("%s","-".repeat(20));


        for (int i = 0; i < NUM_OF_ROWS; i++){
            System.out.printf("\n %c |",columnlabel[i]);
            for(int j = 0; j<movieAvailablity[i].length;j++){

                movieAvailablity[i][j] = (int)(Math.random()*2);
                System.out.print(movieAvailablity[i][j] + " ");


            }



        }


        return movieAvailablity;

    }
}
