package weekSeven;

public class car {
    String cartype;
    String plate;
    String engine;


    public car(String name, String plate_info,String engine_type){
        this.cartype = name;
        this.plate = plate_info;
        this.engine = engine_type;

    }
}
