package weekSeven;

public class student {
    String studentname;
    int studentid;
    String major;


    public student(String name, int SID,String Major){
        this.studentname = name;
        this.studentid = SID;
        this.major = Major;

    }
}

