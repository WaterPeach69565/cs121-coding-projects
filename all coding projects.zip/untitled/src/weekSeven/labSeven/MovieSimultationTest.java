package weekSeven.labSeven;

public class MovieSimultationTest {
    static public void main(String[] args){

       


    }
}
