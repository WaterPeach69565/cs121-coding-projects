package weekSeven;

public class testclass {
    public static void main(String[] args){
        student student_1 = new student("drew",12334,"Computer science");
        System.out.print(student_1.studentname);
        System.out.print(student_1.studentid);
        System.out.print(student_1.major);
        System.out.println(" ");
        student studentnull = new student("null",00000,"null");
        System.out.print(studentnull.studentname);
        System.out.print(studentnull.studentid);
        System.out.print(studentnull.major);
        car car_1 = new car("genesis G70","260DBA","2.2 twin turbo");
        System.out.print(car_1.cartype);
        System.out.print(car_1.plate);
        System.out.print(car_1.engine);
    }



}
