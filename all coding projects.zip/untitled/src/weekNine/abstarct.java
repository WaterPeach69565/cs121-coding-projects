package weekNine;

abstract class abstarct {

    public interface transaction{



    }



    class savings extends abstarct{
        protected String account_holder;
        protected String account_type;
        protected int account_ID;
        protected int account_balance;





    }
    class checkings extends abstarct{
        protected int overdraft;


    }




}
class deposit extends  abstarct{



}
class withdrawl extends abstarct{



}