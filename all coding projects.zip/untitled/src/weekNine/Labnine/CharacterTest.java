package weekNine.Labnine;

public class CharacterTest {
    static int enemy_health = 100;
   static public class Character{
      public int health = 100;

        int enemy_attack = (int) (Math.random()*11);



    }
    public static class Fighter extends  Character{

        public void Attack(){
            int damage = (int) (Math.random()*6);

            int hitchance = (int) (Math.random()*21);
        enemy_health = enemy_health - damage;
        System.out.println("the warrior has hit the enemy for: "+damage+" points of damage leaving: "+enemy_health+" of the enemies health left");
        if(hitchance >=15){
            health = health - enemy_attack;
            System.out.println("the enemy has hit the warrior for: "+enemy_attack+" points of damage leaving: "+health+" of the warriors health left");
        } else {
            System.out.println("The enemy missed");
        }


        }
        public void defend(){
            int defend = (int) (Math.random()*6);
            enemy_attack = enemy_attack - health ;
            System.out.println("the warrior has defended against the enemy for: "+defend+" points of damage leaving: "+health+" of health left");


        }

    }
    public static class Wizard extends Character{

        public void Attack(){
            int hitchance = (int) (Math.random()*21);
            int damage = (int) (Math.random()*11);
            enemy_health = enemy_health - damage;
            System.out.println("the mage has hit the enemy for: "+damage+" points of damage leaving: "+enemy_health+" of the enemies health left");
            if(hitchance >=12){
                health = health - enemy_attack;
                System.out.println("the enemy has hit the mage for: "+enemy_attack+" points of damage leaving: "+health+" of the mage health left");
            } else {
                System.out.println("The enemy missed");
            }

        }
        public void defend(){
            int defend = (int) (Math.random()*6);
            enemy_attack = enemy_attack - health;
            System.out.println("the mage has defended against the enemy for: "+defend+" points of damage leaving: "+health+" of health left");


        }
    }
    public static class Rouge extends  Character{

        public void Attack(){
            int hitchance = (int) (Math.random()*21);
            int damage = (int) (Math.random()*9);
            enemy_health = enemy_health - damage;
            System.out.println("the rouge has hit the enemy for: "+damage+" points of damage leaving: "+enemy_health+" of the enemies health left");
            if(hitchance >=13){
                health = health - enemy_attack;
                System.out.println("the enemy has hit the rouge for: "+damage+" points of damage leaving: "+health+" of the rouge health left");
            } else {
                System.out.println("The enemy missed");
            }

        }
        public void defend(){
            int defend = (int) (Math.random()*6);
            enemy_attack = enemy_attack - health;
            System.out.println("the rouge has defended against the enemy for: "+defend+" points of damage leaving: "+health+" of health left");


        }


    }



}
