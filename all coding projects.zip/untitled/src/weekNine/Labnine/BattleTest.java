package weekNine.Labnine;

import javax.swing.*;
import java.util.Scanner;

public class BattleTest extends CharacterTest{
    static Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) {
// Creates two characters for the battle
        Fighter warrior;
        Wizard wizard = new Wizard();
        warrior = new Fighter();
        Rouge rouge = new Rouge();

       while (CharacterTest.enemy_health >0 || warrior.health == 0){
           int choice = scanner.nextInt();
           if(choice == 1){
               warrior.Attack();
               System.out.println(warrior.health);
           } else if (choice == 2) {
                warrior.defend();
           }


       }
        while (CharacterTest.enemy_health >0|| wizard.health == 0){
            int choice = scanner.nextInt();
            if(choice == 1){
                wizard.Attack();
                System.out.println(warrior.health);
            } else if (choice == 2) {
                wizard.defend();
            }


        }
        while (CharacterTest.enemy_health >0|| rouge.health == 0){
            int choice = scanner.nextInt();
            if(choice == 1){
                rouge.Attack();
                System.out.println(warrior.health);
            } else if (choice == 2) {
                rouge.defend();
            }


        }


       scanner.close();


}


}