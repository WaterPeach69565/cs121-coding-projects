import weekTwo.ActivityOne;

import java.text.Format;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import javax.swing.JOptionPane;

//test bed as this one actual has the needed source code to work I am having trouble with some formatting

public class Main {
    public static void main(String args[]) {
        
        }

    }
