package weekThree;

import javax.swing.*;
import java.util.Scanner;

public class resturantSelecter {
    public static void main(String[] args){


        Scanner vegan = new Scanner(System.in);
        Scanner vegetarian = new Scanner(System.in);
        Scanner glutenF = new Scanner(System.in);
        System.out.println("are there vegans in your group:");
        String vegan_c = vegan.nextLine();
        System.out.println("are there vegetarians in your group:");
        String vegetarian_c = vegetarian.nextLine();
        System.out.println("are there people with gluten based problems:");
        String gluten_c = glutenF.nextLine();


        String[] resturants = {"Joe’s Gourmet Burgers","Main Street Pizza Company ","Corner Café – Vegetarian","Mama’s Fine Italian","The Chef’s Kitchen"};

        // works
        if (vegan_c.equals("yes") && vegetarian_c.equals("yes") && gluten_c.equals("yes")){
            System.out.println(resturants[4]);
            System.out.println(resturants[2]);

        }
        // works
        if (vegan_c.equals("no") && vegetarian_c.equals("no") && gluten_c.equals("no")){
            System.out.println(resturants[0]);

        }
        // works
        if (vegan_c.equals("yes") && vegetarian_c.equals("no") && gluten_c.equals("yes")){
            System.out.println(resturants[1]);

        }
        // works
        if (vegan_c.equals("yes") && vegetarian_c.equals("no") && gluten_c.equals("no")){
            System.out.println(resturants[3]);

        }

        // completed at 10:31


















    }
}
