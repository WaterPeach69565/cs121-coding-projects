package weekThree.LabThree;

import javax.swing.*;

public class Triangles {
    public static void main(String[] args){
        int side_1;
        int side_2;
        int side_3;
        side_1 = Integer.parseInt(JOptionPane.showInputDialog("Enter side 1"));
        side_2 = Integer.parseInt(JOptionPane.showInputDialog("Enter side 2"));
        side_3 = Integer.parseInt(JOptionPane.showInputDialog("Enter side 3"));

        if (side_1 == side_2 && side_1 == side_3){
            JOptionPane.showMessageDialog(null,"The triangle is an Equilateral");

        } else if (side_1 == side_2) {
            JOptionPane.showMessageDialog(null,"The triangle is an Isosceles");


        }
        else {
            JOptionPane.showMessageDialog(null,"The triangle is a Scalene");
        }

    }
}
