package weekThree.LabThree;

import javax.swing.*;

public class Login {
    public static void main(String[] args){
        String password = "1234@5";
        String username = "AnDrew";

        String attempt_password;
        String attempt_username;

        attempt_username = JOptionPane.showInputDialog("Enter user name:");
        attempt_password = JOptionPane.showInputDialog("Enter password:");

        if (attempt_username.equals(username) && (attempt_password.equals(password))){
            System.out.println("correct");
            JOptionPane.showMessageDialog(null, "Welcome to CS121");
        } else if (attempt_username.equals(username)) {
            JOptionPane.showMessageDialog(null, "incorrect password");


        } else if (attempt_password.equals(password)) {
            JOptionPane.showMessageDialog(null, "incorrect username");

        } else {
            JOptionPane.showMessageDialog(null, "incorrect username and password");
        }


    }

}
