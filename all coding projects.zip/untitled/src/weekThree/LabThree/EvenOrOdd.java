package weekThree.LabThree;

import java.util.Scanner;

public class EvenOrOdd {
    public static void main(String[] args){


        Scanner myobject = new Scanner(System.in);
        int num = myobject.nextInt();


        if (num % 2 == 0){
            System.out.println(num + " is even");

        }
        else {
            System.out.println("the number is odd");
        }
    }

}
