package weekThree;

import javax.swing.*;

public class SwitchStatement {
    public static void main(String[] args){


        //Hufflepuff, Gryffindor, Ravenclaw, Slytherin

        //finished at 10:17

        String Hogwartshouse;
        Hogwartshouse = JOptionPane.showInputDialog("enter a house of hogwarts:");

        switch (Hogwartshouse){
            case "Hufflepuff":

                JOptionPane.showMessageDialog(null,"HufflePuff is a house dedicated to hard work, loyalty, fairness, and patience");

                break;

            case "Gryffindor":

                JOptionPane.showMessageDialog(null,"Gryffindor is a house dedicated to bravery, nerve, daring, and chivalry");


                break;

            case "Ravenclaw":

                JOptionPane.showMessageDialog(null,"RavenClaw is a house dedicated to intelligence, creativity, wit, knowledge, and curiosity");

                break;

            case "Slytherin":

                JOptionPane.showMessageDialog(null,"Slytherin is a house dedicated to ambition, leadership, self-preservation, cunning and resourcefulness");

                break;

            default:
                JOptionPane.showMessageDialog(null,"No house entered");

        }







    }
}
